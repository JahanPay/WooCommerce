﻿<?php
/*
Plugin Name:  درگاه پرداخت جهان پی - ووکامرس
Plugin URI: http://jahanpay.me
Description: درگاه پرداخت ووکامرس - جهان پی
Version: 1.0
Author: jahanpay
Author URI: http://jahanpay.me
Copyright: 2016 jahanpay.me
*/
session_start();
add_action('plugins_loaded', 'WC_jahanpay', 0); 

function WC_jahanpay() 
{
    if ( !class_exists( 'WC_Payment_Gateway' ) ) 
		return;
	
    class WC_full_jahanpay extends WC_Payment_Gateway
	{
        public function __construct()
		{
        	
            $this ->id 			 	 = 'jahanpay';
            $this ->method_title 	  	 = 'جهان پی';
            $this ->has_fields 	   	 = false;
            $this ->init_form_fields();
            $this ->init_settings();
			
			$this->title				= $this->settings['title'];
			$this->description			= $this->settings['description'];
			$this->api_jahanpay			 	= $this->settings['api_jahanpay'];
			$this ->redirect_page_id	= $this ->settings['redirect_page_id'];
 
			$this ->msg['message'] = "";
			$this ->msg['class'] = "";
 
			add_action('woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'check_jahanpay_response' ) );
			add_action('valid-jahanpay-request', array($this, 'successful_request'));

  		    if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) 
                add_action( 'woocommerce_update_options_payment_gateways_jahanpay', array( &$this, 'process_admin_options' ) );
             else 
                add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) );
			 
			add_action('woocommerce_receipt_jahanpay', array(&$this, 'receipt_page'));
        }

       function init_form_fields()
	   {
            $this ->form_fields = array(
                'enabled' =>array(
                    'title' =>'فعال سازی/غیر فعال سازی :',
                    'type' =>'checkbox',
                    'label' =>'فعال سازی درگاه پرداخت جهان پی',
                    'description' =>'برای امکان پرداخت کاربران از طریق این درگاه باید تیک فعال سازی زده شده باشد .',
                    'default' =>'no'),
                'api_jahanpay' =>array(
                    'title' =>'API درگاه : ',
                    'type' =>'text',
                    'description' =>'شناسه درگاه api خود را وارد نمایید . <br><a target="_blank" href="http://jahanpay.me">مشاهده api درگاه شما</a>'),
                'title' =>array(
                    'title' =>'عنوان درگاه :',
                    'type'=>'text',
                    'description' =>'این عتوان در سایت برای کاربر نمایش داده می شود .',
                    'default' =>'درگاه پرداخت جهان پی'),
                'description' =>array(
                    'title' =>'توضیحات درگاه :',
                    'type' =>'textarea',
                    'description' =>'این توضیحات در سایت، بعد از انتخاب درگاه توسط کاربر نمایش داده می شود .',
                    'default' =>'پرداخت وجه از طریق درگاه جهان پی توسط تمام کارت های عضو شتاب .'),
				'redirect_page_id' =>array(
                    'title' =>'آدرس بازگشت',
                    'type' =>'select',
                    'options' =>$this ->get_pages('صفحه مورد نظر را انتخاب نمایید'),
                    'description' =>"صفحه‌ای که در صورت پرداخت موفق نشان داده می‌شود را نشان دهید."),
            );
        }
		
        public function admin_options()
		{
            echo '<h3>'.__('درگاه پرداخت جهان پی', 'jahanpay').'</h3>';
            echo '<p>'.__('درگاه پرداخت اینترنتی جهان پی').'</p>';
            echo '<table class="form-table">';
            $this ->generate_settings_html();
            echo '</table>';
		}

		function receipt_page($order_id)
		{
            global $woocommerce;
            $order = new WC_Order($order_id);
            $redirect_url = ($this ->redirect_page_id=="" || $this ->redirect_page_id==0)?get_site_url() . "/":get_permalink($this ->redirect_page_id);
			$redirect_url = add_query_arg( 'wc-api', get_class( $this ), $redirect_url );
			unset( $woocommerce->session->zegersot );
			unset( $woocommerce->session->zegersot_id );
			$woocommerce->session->zegersot = $order_id;
			


			$amount = round($order ->order_total)/10;

			$items_list = NULL;
			foreach ($order->get_items() as $item)
			{
				if(isset($items_list))
					$items_list .= "-" . $item['name'];
				else
					$items_list = $item['name'];
			}
			 $_SESSION['order_id']	= $order_id;
			$api = $this ->api_jahanpay;
			$redirect_url = $redirect_url . '&order_id=' . $order_id; 
			$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
			$res = $client->requestpayment($api, $amount, $redirect_url, $order_id);	
			if($res['result']==1)
			{ 
							$_SESSION['JP_au'] = $res['au']; // dar database save conid b hamrahe order_id , amount

				$woocommerce->session->zegersot_id = $result;
			echo ('<div style="display:none;">'.$res['form'].'</div><script>document.forms["jahanpay"].submit();</script>');
				
			}
			else
				echo '<meta charset=utf-8><pre>';
	$res = array_map('urldecode',$res);
	print_r($res);
        }
        
        function process_payment($order_id)
		{
            $order = &new WC_Order($order_id);
			return array('result' =>'success', 'redirect' =>$order->get_checkout_payment_url( true )); 
        }
	

	    function check_jahanpay_response()
		{
			global $woocommerce;
			$order_id = $_SESSION['order_id'];
							$au 		= $_SESSION['JP_au'];

			$order = &new WC_Order($order_id);
			$api = $this ->api_jahanpay;
			$amount = round($order ->order_total)/10;
			

			if(!empty($au))
			{
				$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
					$res = $client->verification($api , $amount , $au , $order_id, $_POST + $_GET );
				if( ! empty($res['result']) and $res['result'] == 1)
				{
					$this ->msg['message'] = "پرداخت شما با موفقیت انجام شد";
					$this ->msg['class'] = 'woocommerce_message';
					$order ->payment_complete();
					$order ->add_order_note($this->msg['message']);
					$order ->add_order_note('پرداخت انجام شد<br/>کد پیگیری : '.$au);					
					$woocommerce ->cart ->empty_cart();
					wp_redirect( add_query_arg( 'wc_status', 'success', $this->get_return_url( $order ) ) );
					exit;
				}
				else
				{
					$this ->msg['class'] = 'woocommerce_error';
					$this ->msg['message'] = "خطا ({$result}) : {$errorCode[$result]}";	
					$order ->add_order_note('پرداخت ناموفق');
					$order ->add_order_note($this ->msg['message']);
				}	
			}
			else
			{
				$this ->msg['class'] = 'woocommerce_error';
				$this ->msg['message'] = "پرداخت ناموفق";	
				$order ->add_order_note('اطلاعات ارسالی صحیح نمیباشد .');
				$order ->add_order_note($this ->msg['message']);
			}
								unset($_SESSION['JP_au']);
					unset($_SESSION['order_id']);
			$redirect_url = ($this ->redirect_page_id=="" || $this ->redirect_page_id==0)?get_site_url() . "/":get_permalink($this ->redirect_page_id);
			$redirect_url = add_query_arg( array('msg'=>base64_encode($this ->msg['message']), 'type'=>$this ->msg['class']), $redirect_url );
			wp_redirect( $redirect_url );
            exit;
		}

	    function get_pages($title = false, $indent = true) 
		{
	        $wp_pages = get_pages('sort_column=menu_order');
	        $page_list = array();
	        if ($title) $page_list[] = $title;
	        foreach ($wp_pages as $page) 
			{
	            $prefix = '';
	            if ($indent) 
				{
	                $has_parent = $page->post_parent;
	                while($has_parent) 
					{
	                    $prefix .=  ' - ';
	                    $next_page = get_page($has_parent);
	                    $has_parent = $next_page->post_parent;
	                }
	            }
	            $page_list[$page->ID] = $prefix . $page->post_title;
	        }
	        return $page_list;
	    }
	}

    function woocommerce_add_jahanpay_gateway($methods) 
	{
        $methods[] = 'WC_full_jahanpay';
        return $methods;
    }
    add_filter('woocommerce_payment_gateways', 'woocommerce_add_jahanpay_gateway' );
}

if($_GET['message']!='')
{
	add_action('the_content', 'showMessage');
	
	function showMessage($content)
	{
			return '<div class="'.htmlentities($_GET['class']).'">'.base64_decode($_GET['message']).'</div>'.$content;
	}
}
?>